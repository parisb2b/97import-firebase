# Design System Document

## 1. Overview & Creative North Star: "The Editorial Importer"
This design system is built to transform a utilitarian logistics platform into a premium, editorial-grade digital experience. The **Creative North Star** is "The Digital Curator"—a system that treats heavy machinery and industrial imports with the same visual reverence as luxury architectural goods. 

We break the "standard template" look by utilizing intentional asymmetry, high-contrast typography scales, and a departure from traditional containment. Instead of rigid boxes, we use layered surfaces and expansive breathing room to create an interface that feels both authoritative and approachable.

## 2. Color System
Our palette moves beyond simple blues and whites, utilizing a sophisticated tonal range to guide the user's eye.

### Primary Palette
- **Primary Blue (`#0059bb`):** The core of our authority. Used for navigation icons, headers, and primary actions.
- **Secondary Coral/Orange (`#954921` / Container: `#fc9b6c`):** Reserved exclusively for high-conversion value markers (e.g., 'PRIX-50%'). It provides a warm, urgent contrast to the cool primary blues.
- **Hero Gradient:** A linear transition from `primary_container` (`#0070ea`) at the top to `surface_bright` (`#f6faff`) at the base, creating a sense of "sky-high" possibility.

### The Rules of Surface
- **The "No-Line" Rule:** 1px solid borders are strictly prohibited for sectioning. Boundaries must be defined through background color shifts. For example, a `surface-container-low` section sitting on a `surface` background provides all the separation needed without the "clutter" of lines.
- **Signature Textures:** For the main 'RECHERCHER' button and Hero CTAs, use a subtle gradient from `primary` to `primary_container`. This adds a three-dimensional "soul" to the UI.
- **Glassmorphism:** Floating elements, such as the search bar or overlay cards, should utilize `surface_container_lowest` with an 80% opacity and a `16px` backdrop-blur.

## 3. Typography
We use a dual-typeface system to balance technical precision with editorial flair.

- **Headings (Be Vietnam Pro):** Our "Display" and "Headline" scales use this bold, geometric sans-serif. It is large, confident, and colored in `on_primary_fixed_variant` to ensure maximum authority.
- **Body & Labels (Work Sans):** Chosen for its exceptional legibility at small sizes. Used for descriptions and navigational labels.
- **Scale usage:**
    - **Display-LG (`3.5rem`):** Reserved for hero value propositions.
    - **Headline-SM (`1.5rem`):** Used for product category titles in cards.
    - **Body-MD (`0.875rem`):** The standard for descriptive text.

## 4. Elevation & Depth
In this design system, depth is a functional tool, not a decoration. We move away from "drop shadows" toward **Tonal Layering**.

- **The Layering Principle:** Place `surface-container-lowest` (pure white) cards onto a `surface-container-low` background. This creates a natural, soft lift.
- **Ambient Shadows:** When a floating effect is required (like the Hero search bar), use a multi-layered shadow:
    - `0px 4px 20px rgba(21, 28, 34, 0.06)` (A tint of the `on_surface` color).
- **The "Ghost Border":** If accessibility requires a container boundary, use the `outline_variant` at **15% opacity**. Never use 100% opaque borders.

## 5. Components

### Navigation Bar
- **Style:** Horizontal layout, icons centered above labels.
- **Interaction:** The active state uses a `surface_container_high` background with a `primary` icon. 
- **Icons:** Minimalist, thin-stroke (2px) icons for "Accueil," "Mini-Pelle," etc. All icons must be unified in stroke weight.

### Product Cards
- **Structure:** Forbid divider lines. Use `md` (12px) border radius.
- **Content:** Large imagery sits on top, followed by a `headline-sm` title. 
- **CTA:** The 'PRIX-50%' button must span the full width of the card's internal padding, using the `secondary_container` background.

### Buttons
- **Primary ('RECHERCHER'):** Solid `primary` blue, `DEFAULT` (8px) radius, `label-md` uppercase text.
- **Secondary (WhatsApp/Contact):** Uses `tertiary_container` (Seafoam Green) to distinguish service-based actions from sales-based actions.

### Input Fields
- **Search Bar:** A pure white (`surface_container_lowest`) pill-shaped container with a "Ghost Border." The text should be `body-md` in `on_surface_variant`.

## 6. Do's and Don'ts

### Do:
- **Use White Space as a Separator:** Allow at least `32px` of vertical space between the Hero section and the Product Grid.
- **Embrace Asymmetry:** Allow product images (like the Excavator or Boat) to slightly "break" their container's invisible boundaries through clever masking to create a 3D effect.
- **Consistent Iconography:** Ensure the "TikTok" and "Instagram" footer icons share the same circular bounding box and `on_surface` color.

### Don't:
- **No Heavy Outlines:** Never use a dark grey or black border around cards.
- **No Flat Backgrounds:** Avoid a single `#ffffff` background for the entire page; use the `surface` to `surface-container` tiers to create a "top-down" hierarchy.
- **No Crowding:** Do not let the "Services" or "Contact" nav items touch; maintain a minimum of `16px` horizontal padding between navigation items.